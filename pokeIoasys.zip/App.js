import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image, TextInput } from 'react-native';

export default function App() {
  return (
    <View>
      <View style={{backgroundColor: "#EC0344", width: '100%', height: 17}}></View>
      <View style={styles.container}>
        <Image source={require('./assets/Vector.png')} style={styles.imagem}></Image>
        <Text style={styles.texto}>ioasys pokédex</Text>


      </View>
      <View style={styles.coreima}>
        <View>
          <Text style={styles.texto2} > Buscar</Text>
          <View style={{flexDirection: 'row'}}>
            <TextInput style={styles.texto3} placeholder='Buscar pokemon'></TextInput>
            <Image style={{marginTop: 11}} source={require('./assets/Lupa.png')}></Image>
          </View>
        </View>
        <View style={styles.coreima1}>
          <Image source={require('./assets/core.png')}></Image>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    marginTop: 40,
    marginLeft: 50,





  },
  texto: {
    color: "#EC0344",
    fontSize: 30,
    fontWeight: 'bold',


  },
  imagem: {
    marginTop: 13,
    marginRight: 9,
  },
  texto2: {
    color: '#EC0344',
    fontWeight: 'bold',
    marginTop: 60,
    marginLeft: 83,
    fontSize: 16,





  },
  texto3: {
    marginTop: 6,
    marginLeft: 87,
    marginRight: 80,




  },
  coreima: {
    flexDirection: 'row',

  },
  coreima1: {
    marginTop: 92,
    marginLeft: 50
  },
  
});
